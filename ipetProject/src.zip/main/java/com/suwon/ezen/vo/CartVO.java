package com.suwon.ezen.vo;

import lombok.Data;

@Data
public class CartVO {
	private int mno;
	private int pno;
	private String id;
	private String pname;
	private String price;
	private String imageName;
	private String category;
}

package com.suwon.ezen.vo;

import lombok.Data;

@Data
public class EmailAuthVO {
	private String email;
	private String auth;
}

package com.suwon.ezen.vo;

import lombok.Data;

@Data
public class ImageTableVO {
	private int bno;
	private int rno;
	private int pno;
	private String fileName;
	private String id;
}
